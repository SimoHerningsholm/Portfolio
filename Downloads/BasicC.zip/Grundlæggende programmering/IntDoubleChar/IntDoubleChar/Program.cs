﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IntDoubleChar
{
    class Program
    {
        static void Main(string[] args)
        {
            int heltal = 5;
            double kommatal = 5.65;
            char karakter = 'a';
            Console.WriteLine(heltal);
            Console.WriteLine(kommatal);
            Console.WriteLine(karakter);
            Console.ReadLine();
        }
    }
}
