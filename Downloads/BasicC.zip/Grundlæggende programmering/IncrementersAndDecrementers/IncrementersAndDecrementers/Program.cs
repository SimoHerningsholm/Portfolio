﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IncrementersAndDecrementers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 4;
            Console.WriteLine(a);
            a++;
            Console.WriteLine(a);
            ++a;
            Console.WriteLine(a);
            a--;
            Console.WriteLine(a);
            --a;
            Console.WriteLine(a);
            Console.ReadLine();
        }
    }
}
