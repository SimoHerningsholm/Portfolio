﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UdskrivMedPlaceholders
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Opret følgende variabler: Fornavn, efternavn, adresse (gade/vej), husnummer, postnummer, by, fødselsdato, alder (i år). Vælg selv type. Udskriv dem ved hjælp af placeholders. */
            string fornavn = "Simon";
            string efternavn = "Christensen";
            string adresse = "Birk Centerpark";
            string husnummer = "89C";
            string postnummer = "7400";
            string by = "herning";
            string fødselsdato = "28/03/1990";
            string alder = "30";
            Console.WriteLine("fornavn: {0},  efternavn: {1}, adresse: {2}, husnummer: {3}, postnummer: {4}, by: {5}, fødselsdato {6}, alder: {7}.", fornavn, efternavn, adresse, husnummer, postnummer, by, fødselsdato, alder);
            Console.ReadLine();
        }
    }
}
