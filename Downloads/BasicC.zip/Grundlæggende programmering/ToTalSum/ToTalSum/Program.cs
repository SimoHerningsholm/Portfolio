﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToTalSum
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Indtast tal 1");
            int tal01 = int.Parse(Console.ReadLine());
            Console.WriteLine("Indtast tal 2");
            int tal02 = int.Parse(Console.ReadLine());
            Console.WriteLine("summen bliver: " + (tal01 + tal02).ToString());
            Console.ReadLine();
        }
    }
}
