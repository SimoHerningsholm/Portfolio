﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace LoopOpgaver
{
    class Program
    {
        static void Main(string[] args)
        {
            //2
            string[] femElementer = { "1", "2", "3", "4", "5" };
            //3
            Console.WriteLine("For loop");
            for (int i = 0; i < femElementer.Length; i++)
            {
                Console.WriteLine(femElementer[i]);
            }
            Console.WriteLine("Foreach");
            foreach(string derp in femElementer)
            {
                Console.WriteLine(derp);
            }
            Console.WriteLine("while");
            int whileCounter = 0;
            while(whileCounter < femElementer.Length)
            {
                Console.WriteLine(femElementer[whileCounter]);
                whileCounter++;
            }
            Console.WriteLine("do while");
            int doWhileCounter = 0;
            do
            {
                Console.WriteLine(femElementer[doWhileCounter]);
                doWhileCounter++;
            }
            while (doWhileCounter < femElementer.Length);
            //4
            int[] intArr01 = new int[5];
            int[] intArr02 = new int[5];
            //5
            for (int i = 0; i < intArr01.Length; i++)
            {
                intArr01[i] = intArr01.Length - i;
            }
            Console.WriteLine("//5");
            for (int i = 0; i < intArr01.Length; i++)
            {
                Console.WriteLine(intArr01[i]);
            }
            //6
            Console.WriteLine("//6");
            int derpCounter = 0;
            while(derpCounter < intArr02.Length)
            {
                intArr02[derpCounter] = derpCounter + 1;
                derpCounter++;
            }
            for (int i = 0; i < intArr02.Length; i++)
            {
                Console.WriteLine(intArr02[i]);
            }
            //7
            List<int> intList01 = new List<int>();
            List<int> intList02 = new List<int>();
            for (int i = 0; i < 5; i++)
            {
                intList01.Add(5 - i);
            }
            for (int i = 0; i < intList01.Count; i++)
            {
                Console.WriteLine(intList01[i]);
            }
            int derpCounter2 = 0;
            while (derpCounter2 < 5)
            {
                intList02.Add(derpCounter2 + 1);
                derpCounter2++;
            }
            for (int i = 0; i < intList02.Count; i++)
            {
                Console.WriteLine(intList02[i]);
            }
            Console.ReadLine();
        }
    }
}
