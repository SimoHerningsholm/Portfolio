﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToVariabler
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 66;
            int b = 33;
            Console.WriteLine("a:" + a.ToString() + " b:" + b.ToString());
            Console.ReadLine();
        }
    }
}
