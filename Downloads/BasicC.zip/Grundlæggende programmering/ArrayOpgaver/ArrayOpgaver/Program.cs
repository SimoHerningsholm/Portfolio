﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ArrayOpgaver
{
    class Program
    {
        static void Main(string[] args)
        {
            //5
            string[] femOrd = { "Dette", "array", "indeholder", "fem", "ord" };
            //6
            Console.WriteLine(femOrd[2]);
            Console.WriteLine(femOrd[3]);
            //7
            int[] tiTal = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            //8
            int sum = tiTal[1] + tiTal[3] + tiTal[5] + tiTal[8];
            //9
            string[,] ord = {{"kage", "haps", "benny", "bent", "derp" }, { "kage", "haps", "benny", "bent", "derp" }, { "kage", "haps", "lagkage", "bent", "derp" }, { "kage", "haps", "benny", "bent", "derp" }, { "kage", "haps", "benny", "bent", "spillemadingedus" }};
            //10
            Console.WriteLine(ord[2,2]);
            Console.WriteLine(ord[4,4]);
            //11
            int[,] punkter = { { 1, 4 }, { 6, 9 }, { 2, 5 }, { 8, 4 }, { 6, 7 }, { 3, 8 }, { 4, 5 } };
            //12 fortolkning 1
            int ySummer = 0;
            int krydsSummer = 0; // duer ikke i fortolkning 1
            for (int i = 0; i < punkter.Length; i++)
            {
                ySummer += punkter[i,1]; //42
            }
            for (int i = 0; i < punkter.Length; i++)
            {
                ySummer += punkter[i, 1]; //42
            }
            //12 fortolkning 2
            int[,] squareGrid = new int[7, 7];
            //Giver værdier til array
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    squareGrid[i, j] = j + i;
                }
            }
            //Summere x værdier for hver y og udskriver
            int samletYSum = 0;
            for (int i = 0; i < 7; i++)
            {
                int ySummer2 = 0;
                for (int j = 0; j < 7; j++)
                {
                    ySummer += j + i;
                    Console.Write(squareGrid[i, j] + " ");

                }
                Console.Write("sum: " + ySummer2);
                samletYSum += ySummer2;
                Console.Write("\n");
            }
            Console.WriteLine("Samlet y sum: " + samletYSum);
            //Finder krydssum
            int krydsSummer2 = 0;
            for (int i = 0; i < 7; i++)
            {
                for (int j = 0; j < 7; j++)
                {
                    if(j == i)
                    {
                        krydsSummer2 += squareGrid[i, j];
                    }
                }
            }
            Console.Write("Krydssum: " + krydsSummer2);
            Console.ReadLine();
        }
    }
}
