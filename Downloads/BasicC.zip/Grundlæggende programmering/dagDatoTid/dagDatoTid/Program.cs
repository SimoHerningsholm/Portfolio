﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dagDatoTid
{
    class Program
    {
        static void Main(string[] args)
        {
            var dt = DateTime.Now;
            Console.WriteLine("I dag har vi " + dt.ToString("dddd") + " d. " + dt.ToString("dd") + ". " + dt.ToString("MMMM yyyy") + " og kl. er " + dt.ToString("HH.mm"));
            Console.ReadLine();
        }
    }
}
